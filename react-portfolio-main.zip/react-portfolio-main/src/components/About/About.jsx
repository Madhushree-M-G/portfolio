import React from "react";

import styles from "./About.module.css";
import { getImageUrl } from "../../utils";

export const About = () => {
  return (
    <section className={styles.container} id="about">
      <h2 className={styles.title}>About</h2>
      <div className={styles.content}>
        <img
          src={getImageUrl("about/aboutImage.png")}
          alt="Me sitting with a laptop"
          className={styles.aboutImage}
        />
        <ul className={styles.aboutItems}>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="Cursor icon" />
            <div className={styles.aboutItemText}>
              <h3> Machine Learning Enthusiast </h3>
              <p>
              Aspiring AI/ML engineer with a solid foundation in machine learning, Python, and data analysis. Skilled in developing innovative projects and driven by a passion for leveraging AI to address real-world challenges effectively.
              </p>
            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/serverIcon.png")} alt="Server icon" />
         
            <div className={styles.aboutItemText}>
              <h3> Web Developer</h3>
              <p>
              With hands-on experience in React.js, Node.js, and full-stack development, I have a deep interest in building efficient, scalable web applications
              </p>
            </div>
          </li>
          <li className={styles.aboutItem}>
            <img src={getImageUrl("about/cursorIcon.png")} alt="UI icon" />
           
            <div className={styles.aboutItemText}>
              <h3>Versatile in Emerging Technologies</h3>
              <p>
              I continuously explore cutting-edge technologies, having developed projects like gesture language recognition systems and dynamic web applications
              </p>
            </div>
          </li>
        </ul>
      </div>
    </section>
  );
};
